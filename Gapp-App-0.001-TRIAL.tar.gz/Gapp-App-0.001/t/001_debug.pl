#!/usr/bin/perl -w
use strict;



use Test::More tests => 1;


use_ok 'Gapp::App::Debug';
use Gapp::App::Debug qw(debug);



